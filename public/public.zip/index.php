<?php
require_once "../config/Conexion.php";
require_once "../modelos/Noticia.php";

$noticia = new Noticia();
// Llamamos a las funciones
$listado = $noticia->listarUltimasNoticias();
$rsptaOpinion = $noticia->listarUltimaOpinion();
$opinion = $rsptaOpinion->fetch_object(); 
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TuQ | El valor de la verdad</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;700&family=Playfair+Display:ital,wght@0,900;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <style>
        :root {
            --primary-dark: #1a1a1a;
            --accent-blue: #0056b3;
            --true-green: #2ecc71;
            --false-red: #e74c3c;
        }

        body { font-family: 'Inter', sans-serif; background-color: #fff; color: var(--primary-dark); }
        
        /* Navbar Minimalista */
        .navbar { padding: 1.5rem 0; transition: all 0.3s; }
        .navbar-brand { font-family: 'Playfair Display', serif; font-size: 2rem; font-weight: 900; }
        .nav-link { font-size: 0.85rem; font-weight: 700; letter-spacing: 1px; color: var(--primary-dark) !important; padding: 0.5rem 1.5rem !important; }

        /* Estilo para el Título de Sección (Separador) */
        .section-separator {
            display: flex;
            align-items: center;
            margin-bottom: 3rem;
            margin-top: 1rem;
        }
        .section-separator h2 {
            font-family: 'Playfair Display', serif;
            font-weight: 900;
            font-size: 2.2rem;
            margin-bottom: 0;
            padding-right: 20px;
        }
        .section-separator::after {
            content: "";
            flex-grow: 1;
            height: 2px;
            background-color: #f0f0f0;
        }

        /* Noticia Destacada (Hero) */
        .hero-section { position: relative; border-radius: 20px; overflow: hidden; margin-bottom: 4rem; }
        .main-title { font-family: 'Playfair Display', serif; font-size: 3.5rem; line-height: 1; margin-bottom: 1.5rem; }
        
        /* Sellos de Verificación Pro */
        .sello-veritas {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 50px;
            font-size: 0.7rem;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 1rem;
        }
        .check-verdadero { background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0; }
        .check-falso { background: #fee2e2; color: #b91c1c; border: 1px solid #fecaca; }
        .check-opinión, .check-opinion { background: #e0e7ff; color: #3730a3; border: 1px solid #c7d2fe; }

        /* Tarjetas de la Grilla */
        .card-news { border: none; transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
        .card-news:hover { transform: translateY(-10px); }
        .card-news img { border-radius: 12px; height: 220px; object-fit: cover; }
        .card-news .card-title { font-family: 'Playfair Display', serif; font-size: 1.4rem; font-weight: 900; line-height: 1.2; }

        /* Footer Elegante */
        footer { background: #000; color: #fff; padding: 5rem 0 2rem; margin-top: 5rem; }
        footer h5 { font-family: 'Playfair Display', serif; font-weight: 700; margin-bottom: 1.5rem; }
        footer a { color: #999; text-decoration: none; transition: 0.3s; font-size: 0.9rem; }
        footer a:hover { color: #fff; }

        @media (max-width: 768px) {
            .main-title { font-size: 2rem; }
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg sticky-top bg-white">
    <div class="container">
        <a class="navbar-brand" href="index.php">TuQ<span class="text-primary">.</span></a>
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto text-uppercase">
                <li class="nav-item"><a class="nav-link" href="#">Política</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Economía</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Mundo</a></li>
                <li class="nav-item ms-lg-3">
                    <a class="btn btn-dark rounded-pill px-4 btn-sm" href="../Admin/login.php">Admin</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<main class="container">
    <div class="row">
        <?php 
        $count = 0;
        if($listado && $listado->num_rows > 0):
            while ($reg = $listado->fetch_object()): 
                if ($count == 0): // ARTÍCULO HERO (EL PRIMERO)
        ?>
            <div class="col-12 mb-5">
                <div class="card hero-section border-0 shadow-lg">
                    <div class="row g-0">
                        <div class="col-lg-7">
                            <img src="../files/noticias/<?php echo $reg->imagen; ?>" class="img-fluid w-100 h-100" style="object-fit: cover; min-height: 450px;" alt="...">
                        </div>
                        <div class="col-lg-5 p-5 d-flex flex-column justify-content-center bg-white">
                            <?php if (!empty($reg->calificacion) && $reg->calificacion != 'Noticia'): ?>
                                <div class="sello-veritas check-<?php echo strtolower(str_replace(' ', '-', $reg->calificacion)); ?>">
                                    <i class="fa-solid fa-shield-check me-1"></i> <?php echo $reg->calificacion; ?>
                                </div>
                            <?php endif; ?>
                            
                            <a href="articulo.php?id=<?php echo $reg->idnoticia; ?>" class="text-decoration-none text-dark">
                                <h1 class="main-title"><?php echo $reg->titulo; ?></h1>
                            </a>
                            <p class="lead text-secondary"><?php echo $reg->resumen; ?></p>
                            
                            <div class="d-flex align-items-center mt-4">
                                <div class="flex-grow-1">
                                    <h6 class="mb-0 fw-bold">Por <?php echo $reg->autor; ?></h6>
                                    <small class="text-muted"><?php echo date("M d, Y", strtotime($reg->fecha_publicacion)); ?></small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12">
                <div class="section-separator">
                    <h2>Últimas Noticias</h2>
                </div>
            </div>

            <div class="row g-4"> <?php else: // ARTÍCULOS SECUNDARIOS (Las otras 5 noticias) ?>
            <div class="col-lg-4 col-md-6 mb-4">
                <article class="card h-100 card-news bg-transparent">
                    <div class="position-relative mb-3">
                        <img src="../files/noticias/<?php echo $reg->imagen; ?>" class="card-img-top shadow-sm" alt="...">
                        <span class="badge bg-dark position-absolute top-0 start-0 m-3 rounded-pill" style="font-size: 0.6rem;">
                            <?php echo $reg->categoria; ?>
                        </span>
                    </div>
                    <div class="card-body p-0">
                        <?php if (!empty($reg->calificacion) && $reg->calificacion != 'Noticia'): ?>
                            <div class="sello-veritas check-<?php echo mb_strtolower(str_replace(' ', '-', $reg->calificacion), 'UTF-8'); ?>">
                                <?php echo $reg->calificacion; ?>
                            </div>
                        <?php endif; ?>
                        <a href="articulo.php?id=<?php echo $reg->idnoticia; ?>" class="text-decoration-none text-dark">
                            <h5 class="card-title"><?php echo $reg->titulo; ?></h5>
                        </a>
                        <p class="card-text text-muted small mt-2"><?php echo substr($reg->resumen, 0, 100); ?>...</p>
                    </div>
                </article>
            </div>
        <?php 
                endif;
                $count++;
            endwhile; 
        endif; 
        ?>

        <?php if($opinion): ?>
            <div class="col-lg-4 col-md-6 mb-4">
                <article class="card h-100 card-news bg-transparent">
                    <div class="position-relative mb-3">
                        <img src="../files/noticias/<?php echo $opinion->imagen; ?>" class="card-img-top shadow-sm" alt="...">
                        <span class="badge bg-dark position-absolute top-0 start-0 m-3 rounded-pill" style="font-size: 0.6rem;">
                            <?php echo $opinion->categoria; ?>
                        </span>
                    </div>
                    <div class="card-body p-0">
                        <?php if (!empty($opinion->calificacion) && $opinion->calificacion != 'Noticia'): ?>
                            <div class="sello-veritas check-<?php echo mb_strtolower(str_replace(' ', '-', $opinion->calificacion), 'UTF-8'); ?>">
                                <?php echo $opinion->calificacion; ?>
                            </div>
                        <?php endif; ?>
                        <a href="articulo.php?id=<?php echo $opinion->idnoticia; ?>" class="text-decoration-none text-dark">
                            <h5 class="card-title"><?php echo $opinion->titulo; ?></h5>
                        </a>
                        <p class="card-text text-muted small mt-2"><?php echo substr($opinion->resumen, 0, 100); ?>...</p>
                    </div>
                </article>
            </div>
        <?php endif; ?>

        <?php 
        // Cerramos el row g-4 solo si imprimimos noticias u opinión
        if(($listado && $listado->num_rows > 0) || $opinion) {
            echo '</div>'; 
        } else {
            echo "<div class='col-12 py-5 text-center'><h2 class='display-4 fw-light'>Silencio en la redacción...</h2><p>Vuelve pronto para más noticias.</p></div>";
        }
        ?>

    </div>
</main>

<footer>
    <div class="container text-center text-md-start">
        <div class="row">
            <div class="col-lg-6 mb-5">
                <h1 class="navbar-brand text-white mb-4">TuQ<span class="text-primary">.</span></h1>
                <p class="text-secondary pe-lg-5">Combatimos la desinformación con datos crudos y periodismo de precisión. Porque la verdad no tiene precio, pero sí tiene pruebas.</p>
                <div class="d-flex gap-3 mt-4 justify-content-center justify-content-md-start">
                    <a href="#"><i class="fa-brands fa-x-twitter fs-4"></i></a>
                    <a href="#"><i class="fa-brands fa-instagram fs-4"></i></a>
                    <a href="#"><i class="fa-brands fa-linkedin fs-4"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4">
                <h5>Metodología</h5>
                <ul class="list-unstyled">
                    <li><a href="#">El Sello TuQ</a></li>
                    <li><a href="#">Fuentes Abiertas</a></li>
                    <li><a href="#">Transparencia</a></li>
                </ul>
            </div>
            <div class="col-lg-3 col-md-6 mb-4 text-center bg-dark p-4 rounded-4">
                <h5>Newsletter</h5>
                <p class="small text-secondary">La verdad, cada lunes en tu inbox.</p>
                <div class="input-group">
                    <input type="email" class="form-control bg-transparent border-secondary text-white" placeholder="Tu email">
                    <button class="btn btn-primary"><i class="fa-solid fa-paper-plane"></i></button>
                </div>
            </div>
        </div>
        <div class="border-top border-secondary mt-5 pt-4 text-center">
            <p class="small text-secondary">© 2026 TuQ Media Group. Prohibida la reproducción sin citar la fuente.</p>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>