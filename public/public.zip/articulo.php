<?php
require_once "../config/Conexion.php";
require_once "../modelos/Noticia.php";

$noticia = new Noticia();
$id = isset($_GET["id"]) ? $_GET["id"] : "";

// Obtenemos los datos (tu modelo ya devuelve un array asociativo)
$reg = $noticia->mostrar($id);

// Redirección si no existe la noticia
if (!$reg) { 
    header("Location: index.php"); 
    exit(); 
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $reg['titulo']; ?> | TuQ</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&family=Playfair+Display:ital,wght@0,700;0,900;1,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <style>
        :root {
            --bs-body-font-family: 'Inter', sans-serif;
            --true-green: #2ecc71;
            --false-red: #e74c3c;
            --engañoso-orange: #f39c12;
        }

        body { background-color: #fff; color: #1a1a1a; line-height: 1.8; overflow-x: hidden; }
        
        /* Navbar Superior */
        .navbar { border-bottom: 1px solid #eee; background: rgba(255,255,255,0.9) !important; backdrop-filter: blur(10px); }
        .navbar-brand { font-family: 'Playfair Display', serif; font-weight: 900; font-size: 1.8rem; }

        /* Barra de compartir lateral */
        .share-bar { position: sticky; top: 120px; display: flex; flex-direction: column; gap: 12px; align-items: center; }
        .share-link { width: 42px; height: 42px; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #fff; text-decoration: none; transition: all 0.3s ease; }
        .share-link:hover { transform: translateY(-3px); box-shadow: 0 5px 15px rgba(0,0,0,0.1); color: #fff; }
        .bg-facebook { background-color: #1877f2; }
        .bg-twitter { background-color: #000; }
        .bg-whatsapp { background-color: #25d366; }

        /* Estética del Artículo */
        .category-badge { font-size: 0.75rem; font-weight: 800; letter-spacing: 2px; color: #0056b3; text-transform: uppercase; margin-bottom: 1rem; display: block; }
        .article-title { font-family: 'Playfair Display', serif; font-size: 3.5rem; font-weight: 900; line-height: 1.1; margin-bottom: 2rem; }
        .article-resumen { font-size: 1.3rem; color: #4a5568; font-weight: 400; line-height: 1.6; border-left: 4px solid #0056b3; padding-left: 1.5rem; margin-bottom: 2rem; }

        /* Cuadro de Verificación (Sello) */
        .check-card { border: none; border-radius: 20px; overflow: hidden; box-shadow: 0 15px 35px rgba(0,0,0,0.07); margin-bottom: 3rem; }
        .check-header { padding: 2rem; font-family: 'Playfair Display', serif; font-weight: 900; color: #fff; text-align: center; }
        .check-verdadero { background-color: var(--true-green); }
        .check-falso { background-color: var(--false-red); }
        .check-engañoso { background-color: var(--engañoso-orange); }

        /* Contenido del Cuerpo */
        .featured-image { border-radius: 24px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.15); margin-bottom: 3.5rem; }
        .article-content { font-size: 1.2rem; color: #2d3748; max-width: 760px; margin: 0 auto; }
        .article-content p { margin-bottom: 1.8rem; }

        @media (max-width: 991px) {
            .article-title { font-size: 2.5rem; }
            .share-bar { flex-direction: row; position: relative; top: 0; justify-content: center; margin-bottom: 3rem; }
            .share-bar span { display: none; }
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg sticky-top py-3">
    <div class="container">
        <a class="navbar-brand text-dark" href="index.php">TuQ<span class="text-primary">.</span></a>
        <a href="index.php" class="btn btn-dark rounded-pill px-4 btn-sm fw-bold">
            <i class="fa-solid fa-arrow-left me-2"></i> VOLVER
        </a>
    </div>
</nav>

<div class="container mt-5 pt-lg-2">
    <div class="row justify-content-center">
        
        <div class="col-lg-1 d-none d-lg-block">
            <div class="share-bar">
                <span class="small fw-bold text-muted mb-2" style="writing-mode: vertical-rl; text-orientation: mixed;">COMPARTIR</span>
                <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode("http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']); ?>" target="_blank" class="share-link bg-facebook">
                    <i class="fab fa-facebook-f"></i>
                </a>
                <a href="https://twitter.com/intent/tweet?text=<?php echo urlencode($reg['titulo']); ?>&url=<?php echo urlencode("http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']); ?>" target="_blank" class="share-link bg-twitter">
                    <i class="fa-brands fa-x-twitter"></i>
                </a>
                <a href="https://api.whatsapp.com/send?text=<?php echo urlencode($reg['titulo'] . " " . "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']); ?>" target="_blank" class="share-link bg-whatsapp">
                    <i class="fab fa-whatsapp"></i>
                </a>
            </div>
        </div>

        <div class="col-lg-8">
            <article>
                <header class="mb-5">
                    <span class="category-badge"><?php echo $reg['categoria']; ?></span>
                    <h1 class="article-title"><?php echo $reg['titulo']; ?></h1>
                    <p class="article-resumen"><?php echo $reg['resumen']; ?></p>
                    
                    <div class="d-flex align-items-center mt-4 pt-4 border-top">
                        <div class="flex-grow-1">
                            <span class="text-muted">Escrito por</span> 
                            <b class="text-dark ms-1"><?php echo $reg['autor']; ?></b>
                            <span class="mx-2 text-muted">•</span>
                            <span class="text-muted"><?php echo date("d M, Y", strtotime($reg['fecha_publicacion'])); ?></span>
                        </div>
                    </div>
                </header>

                <?php if (!empty($reg['calificacion'])): ?>
                    <div class="card check-card mb-5">
                        <div class="row g-0">
                            <div class="col-md-3 check-header check-<?php echo strtolower(str_replace(' ', '-', $reg['calificacion'])); ?>">
                                <i class="fa-solid fa-shield-check d-block mb-2 fs-1"></i>
                                <span class="fs-4">CHECK</span>
                            </div>
                            <div class="col-md-9 p-4 bg-white border-start">
                                <h4 class="fw-bold text-dark mb-2"><?php echo $reg['calificacion']; ?></h4>
                                <p class="mb-0 text-secondary small"><?php echo $reg['explicacion_calificacion']; ?></p>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="text-center">
                    <img src="../files/noticias/<?php echo $reg['imagen']; ?>" class="img-fluid featured-image" alt="<?php echo $reg['titulo']; ?>">
                </div>

                <div class="article-content">

                      <?php echo nl2br($reg['cuerpo']); ?>
                </div>

                <footer class="mt-5 pt-5 border-top mb-5 text-center text-md-start">
                    <a href="index.php" class="btn btn-outline-dark btn-lg rounded-pill px-5">
                        <i class="fas fa-chevron-left me-2"></i> Ir a Portada
                    </a>
                </footer>
            </article>
        </div>
    </div>
</div>

<div class="py-5"></div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>