<?php
// Incluimos la conexión y el modelo de noticias
require_once "../config/Conexion.php";
require_once "../modelos/Noticia.php";

$noticia = new Noticia();
/* $listado = $noticia->listar(); */
$listado = $noticia->listarActivos();

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TuQ - Blog de Noticias & Fact Checking</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@900&family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/estilos_blog.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom sticky-top">
    <div class="container">
        <a class="navbar-brand" href="index.php" style="font-weight: 900; letter-spacing: -1px;">
            <span style="color: #0056b3;">TuQ</span>-Blog
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item"><a class="nav-link font-weight-bold" href="#">POLÍTICA</a></li>
                <li class="nav-item"><a class="nav-link font-weight-bold" href="#">ECONOMÍA</a></li>
                <li class="nav-item"><a class="nav-link font-weight-bold" href="#">JUSTICIA</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <div class="row">
        <?php 
        $count = 0;
        if($listado):
            while ($reg = $listado->fetch_object()): 
                if ($count == 0): // LA NOTICIA DESTACADA (GRANDE)
        ?>
            <div class="col-12 mb-5">
                <div class="row no-gutters bg-white shadow-sm border-bottom-blue">
                    <div class="col-md-8">
                        <img src="../files/noticias/<?php echo $reg->imagen; ?>" class="img-fluid w-100 main-img" alt="<?php echo $reg->titulo; ?>">
                    </div>
                    <div class="col-md-4 p-4 d-flex flex-column justify-content-center">
                        <span class="badge-categoria mb-2"><?php echo $reg->categoria; ?></span>
                        
                        <?php if (!empty($reg->calificacion)): ?>
                            <div class="sello-verificacion mb-2 check-<?php echo strtolower(str_replace(' ', '-', $reg->calificacion)); ?>">
                                <?php echo $reg->calificacion; ?>
                            </div>
                        <?php endif; ?>

                        <a href="articulo.php?id=<?php echo $reg->idnoticia; ?>" class="text-dark text-decoration-none">
                            <h1 class="main-title"><?php echo $reg->titulo; ?></h1>
                        </a>
                        <p class="text-muted"><?php echo $reg->resumen; ?></p>
                        <div class="mt-auto">
                            <small class="text-secondary font-weight-bold">Por <?php echo $reg->autor; ?></small>
                        </div>
                    </div>
                </div>
            </div>
        <?php else: // NOTICIAS SECUNDARIAS (GRILLA) ?>
            <div class="col-md-4 mb-4">
                <div class="card h-100 card-noticia border-0 shadow-sm">
                    <div class="position-relative">
                        <img src="../files/noticias/<?php echo $reg->imagen; ?>" class="card-img-top" alt="...">
                        <?php if (!empty($reg->calificacion)): ?>
                            <div class="sello-mini check-<?php echo strtolower(str_replace(' ', '-', $reg->calificacion)); ?>">
                                <?php echo $reg->calificacion; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <span class="badge-categoria-sm"><?php echo $reg->categoria; ?></span>
                        <a href="articulo.php?id=<?php echo $reg->idnoticia; ?>" class="text-dark text-decoration-none">
                            <h5 class="card-title mt-2 font-weight-bold"><?php echo $reg->titulo; ?></h5>
                        </a>
                        <p class="card-text small text-muted"><?php echo substr($reg->resumen, 0, 120); ?>...</p>
                    </div>
                    <div class="card-footer bg-white border-0">
                        <small class="text-muted"><?php echo date("d/m/Y", strtotime($reg->fecha_publicacion)); ?></small>
                    </div>
                </div>
            </div>
        <?php 
                endif;
                $count++;
            endwhile; 
        else:
            echo "<div class='col-12 text-center'><h3>No hay noticias publicadas aún.</h3></div>";
        endif;
        ?>
    </div>
</div>


<footer class="main-footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 mb-4 mb-lg-0">
                <a href="index.php" class="footer-logo">TuQ-PROGRAMA</a>
                <p>Somos una plataforma dedicada a la verificación del discurso público y la lucha contra la desinformación. Nuestro compromiso es con los datos, la transparencia y la verdad.</p>
                <div class="social-links-footer">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-youtube"></i></a>
                </div>
            </div>

            <div class="col-lg-2 col-md-6 mb-4 mb-lg-0">
                <h5>Metodología</h5>
                <ul class="list-unstyled">
                    <li><a href="#">¿Cómo chequeamos?</a></li>
                    <li><a href="#">Nuestra escala de verdad</a></li>
                    <li><a href="#">Fuentes de datos</a></li>
                    <li><a href="#">Política de corrección</a></li>
                </ul>
            </div>

            <div class="col-lg-2 col-md-6 mb-4 mb-lg-0">
                <h5>Proyecto</h5>
                <ul class="list-unstyled">
                    <li><a href="#">Sobre nosotros</a></li>
                    <li><a href="#">Contacto</a></li>
                    <li><a href="#">Sumate como voluntario</a></li>
                    <li><a href="#">Donaciones</a></li>
                </ul>
            </div>

            <div class="col-lg-4">
                <h5>Newsletter</h5>
                <p>Recibí nuestras verificaciones semanales en tu correo.</p>
                <form class="form-inline">
                    <div class="input-group w-100">
                        <input type="email" class="form-control newsletter-input" placeholder="Tu email" aria-label="Email">
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="button">Unirme</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="footer-bottom text-center">
            <div class="row">
                <div class="col-md-12">
                    <p>© 2026 TuQ-Programa. Todos los derechos reservados. | <a href="#">Términos y Condiciones</a> | <a href="#">Privacidad</a></p>
                </div>
            </div>
        </div>
    </div>
</footer>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>